This is a cloned repository of the sample data Google has provided for their data engineering courses. We will be using the same sample data for the Linux Academy Google Cloud Data Engineer course.

All credit for the data rests with Google. We are cloning it to prevent changes causing issues with our exercises.

The original GitHub page is at the below link:
https://github.com/GoogleCloudPlatform/training-data-analyst
