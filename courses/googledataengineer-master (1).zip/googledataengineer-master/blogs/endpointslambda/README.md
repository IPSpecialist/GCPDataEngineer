# Integrating Applications Using Google Cloud Endpoints and AWS Lambda 

The sample is part of a blog post to demonstrate integration of applications running on Google Cloud Platform and Amazon Web Services.
The sample consists of two parts:
* aeflex-endpoints: This folder contains the code for the Endpoints API
* lambdafunctioninline.py: This file contains the code for the AWS Lambda function.


Disclaimer: This is not an official Google product.
